#include <iostream>
#include <vector>
using namespace std;
class diem2d
{
public:
    int x,y;
    diem2d()
    {
        this->x = 0;
        this->y = 0;
    }
    void nhap()
    {
        cin>>x>>y;
    }
    diem2d & operator=(const diem2d & other)
    {
        this->x = other.x;
        this->y= other.y;
        return *this;
    }
    void xuat()
    {
        cout<< x << " " << y;
    }
};
bool lonhon(diem2d A,diem2d B)
{
    if(A.x != B.x)
    {
        return A.x > B.x;
    }   
    return A.y < B.y;
}
bool behon(diem2d A,diem2d B)
{
    if(A.x != B.x)
        return A.x < B.x;
    return A.y > B.y;
}
void swap(diem2d & A,diem2d &B)
{
    diem2d C = A;
    A = B;
    B = C;
}
// quicksort
void sapxep(vector<diem2d> & ds,int left, int right)
{
    int pivot = (left + right)/2;
    if(left>=right)
        return;
    diem2d temp = ds[pivot];
    int i,j;
    i = left;
    j = right;
    while(i <= j)
    {
        while(i<right && behon(ds[i],temp))
            i++;
        while(j > left && lonhon(ds[j],temp))
            j--;
        if(i<=j)
        {
            swap(ds[i],ds[j]);
            i++;
            j--;
        }
        
    }
    if(left < j)
        sapxep(ds,left,j);
    if(right > i)
        sapxep(ds,i, right);
    
}
int main()
{
    ios_base::sync_with_stdio(false);

    cin.tie(nullptr);

    cout.tie(nullptr);

    int n;
    cin>>n;
    vector<diem2d> ds(n);
    for(int i = 0;i<n;i++)
    {
        ds[i].nhap();
    }
    sapxep(ds,0,n-1);
    for(int i = 0;i<n;i++)
    {
        ds[i].xuat();
        cout<< "\n";
    }
}