#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <utility>
using namespace std;
class diem
{
public:
    double x,y,z;
    diem()
    {
        x = 0;
        y = 0;
        z = 0;
    }

    void nhap()
    {
        cin>>x>>y>>z;
    }
    double kc()
    {
        return pow(x,2)+pow(y,2)+pow(z,2);
    }
    bool operator ==(const diem& other)
    {
        if(this->x != other.x)
            return 0;
        if(this->y != other.y)
            return 0;
        if(this->z != other.z)
            return 0;
        return 1;
    }
    
    bool operator <(diem& other)
    {
        return kc() < other.kc();
    }

};

int main()
{
    vector<pair<diem,int>> a(1000); // chua diem ban dau
    int n;
    cin>>n; // so diem
    for(int i = 0;i<n;i++)
    {
        a[i].second = i;
        a[i].first.nhap();
    }
    vector<diem> b(1000); // chua diem pi
    int m;
    cin>>m;
    for(int i=0;i<m;i++)
    {
        b[i].nhap();   
    }
    sort(a.begin(),a.begin()+n,[](pair<diem,int> A,pair<diem,int> B)
    {return A.first.kc() <B.first.kc();});
    for(int i = 0;i<m;i++)
    {
        int index =-1;
        auto it = lower_bound(a.begin(),a.begin()+n,b[i]);
        if(it != a.begin()+n)
            index = it -a.begin();
        if(index >=0)
            cout<< a[index].second<<endl;
        else
            cout<< "KHONG"<<endl;

    }
}