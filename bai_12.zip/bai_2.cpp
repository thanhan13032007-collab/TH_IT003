#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class diem
{

    
public:
    double x,y,z;
    diem()
    {
        x = 0;
        y = 0;
        z = 0;
    }

    void nhap()
    {
        cin>>x>>y>>z;
    }
    bool operator ==(const diem& other)
    {
        if(this->x != other.x)
            return 0;
        if(this->y != other.y)
            return 0;
        if(this->z != other.z)
            return 0;
        return 1;
    }

};
int main()
{

    vector<diem> a(1000); // chua diem ban dau
    int n;
    cin>>n; // so diem
    for(int i = 0;i<n;i++)
    {
        a[i].nhap();
    }
    vector<diem> b(1000); // chua diem pi
    int m;
    cin>>m;
    for(int i=0;i<m;i++)
    {
        b[i].nhap();   
    }
    for(int i = 0;i<m;i++)
    {
        
        int index = -1;
        auto it = find(a.begin(),a.begin()+n,b[i]);
        if(it != a.begin()+n)
            index = it -a.begin();
        if(index >=0)
            cout<< index <<endl;
        else
            cout<< "KHONG" <<endl;
    }

}