#include <iostream>
using namespace std;
void search(int a[],int n,int x)
{
    int left =0;
    int right = n-1;
    bool left_true =1;
    bool right_true =1;
    while((left<=right)|| (left_true==0 && right_true==0))
    {
        if(a[left]==x)
        {
            cout<< left<<endl;
            cout<< left+1<<endl;
            left_true =0;
        }
        if(a[right]==x)
        {
            cout<< n-1 -right<<endl;
            cout<<n-right<<endl;
            right_true = 0;
            
        }  
        if(left_true)
            left++;
        if(right_true)
            right--;
    }
    if(a[left] != x)
        cout<< -1<<endl;
}
int main()
{
    int a[100];
    int n;
    cin>>n;
    for(int i =0;i<n;i++)
    {
        cin>>a[i];
    }
    int x;
    cin>>x;
    search(a,n,x);

}